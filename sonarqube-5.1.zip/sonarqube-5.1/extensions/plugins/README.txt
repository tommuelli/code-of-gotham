Plugins can be downloaded from :
- http://redirect.sonarsource.com/doc/plugin-library.html
- http://www.sonarsource.com/plugins
